﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjetoServiceDesk.Model;
using System.Data;

namespace ProjetoServiceDesk.DAO
{
    internal class FuncionarioBD : Banco
    {
        internal FuncionarioBD() { }

        internal Funcionario Autenticar(string login, string senha)
        {
            ComandoSQL.Parameters.Clear();
            ComandoSQL.CommandText = @"select * from USUARIO
                    where fun_login = @login and fun_senha = @senha";
            ComandoSQL.Parameters.AddWithValue("@login", login);
            ComandoSQL.Parameters.AddWithValue("@senha", senha);

            DataTable dt = ExecutaSelect();
            if (dt != null && dt.Rows.Count > 0)
            {
                Funcionario f = new Funcionario();
                f.Codigo = Convert.ToInt32(dt.Rows[0]["fun_codigo"]);
                f.Login = dt.Rows[0]["fun_login"].ToString();
                f.Senha = dt.Rows[0]["fun_senha"].ToString();
                return f;
            }
            else
                return null;
        }
    }
}
