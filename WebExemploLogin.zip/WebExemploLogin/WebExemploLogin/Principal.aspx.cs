﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebExemploLogin
{
    public partial class Principal : System.Web.UI.Page
    {
        public static void VerificaLogin()
        {
            if (HttpContext.Current.Session["autenticado"] == null ||
                HttpContext.Current.Session["autenticado"].ToString() != "OK")
            {
                HttpContext.Current.Session.Abandon();
                HttpContext.Current.Response.Redirect("Default.aspx?msg=Por favor, autentique-se");
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            VerificaLogin();

            if (Session["autenticado"] != null && Session["autenticado"].ToString() == "OK")
            {
                lblUsuario.Text = string.Format("Código: {0}<br/>Nome: {1}<br/>Senha: {2}",
                    Session["codigoFuncionario"].ToString(),
                    Session["nomeFuncionario"].ToString(),
                    Session["senhaFuncionario"].ToString());
            }
        }

        protected void txtSair_Click(object sender, EventArgs e)
        {
            Response.Redirect("Logout.aspx");
        }
    }
}